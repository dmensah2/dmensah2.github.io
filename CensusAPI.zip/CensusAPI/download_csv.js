function download_csv() {
        //new instance of xmlhttprequest class 
    let request = new XMLHttpRequest();

    //gets inputs from the form
    var variable = document.getElementById("variable");
    var variable_value = variable.options[variable.selectedIndex].value;

    var geography = document.getElementById("geography");
    var geography_value = geography.options[geography.selectedIndex].value;

    //prefix url for which we will append the inputs from the prompts
    const url = "https://api.census.gov/data/2018/acs/acs5/subject?get=";

    //API Key
    const apiKey = "6df8ecbbdd76fb9432d628ae6178349765cba241";

    //constructs url endpoint we will make our request from
    const link = `${url}${variable_value}${",NAME&for="}${geography_value}${" :*&key="}${apiKey}`;

    //begin to access the data
    request.onreadystatechange = () => {
        let data = JSON.parse(request.response);
        //gets the html element we want to put our data in
        if (request.readyState === XMLHttpRequest.DONE) {
            console.log(data);

            var csv = 'Name,Title\n'
            
            data.forEach(function(row) {
                    csv += row.join(',');
                    csv += "\n";
            });
        
            var hiddenElement = document.createElement('a');
            hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
            hiddenElement.target = '_blank';
            hiddenElement.download = 'output.csv';
            hiddenElement.click();
        
        } 
    }

    //opens a new connection, using the GET request on the URL endpoint
    request.open("GET", link);

    //Send request
    request.send();
}